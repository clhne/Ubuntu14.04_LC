#!/usr/bin/env sh
#cat MTCNN/*.txt > MTCNN.txt
cat MTCNN_20/*.txt > MTCNN_20.txt
#cat /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/fileList/*.txt > /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/fileList.txt
#cat /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/ellipseList/*.txt > /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/ellipseList.txt
#cat /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/CascadeCNN/*.txt > /home/xileli/Documents/program/CascadeCNN/result/FDDB_evaluation/FDDB-folds/CascadeCNN.txt

