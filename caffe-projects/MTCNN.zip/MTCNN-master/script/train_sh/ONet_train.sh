#!/usr/bin/env sh
set -e

/Users/Young/caffe/.build_release/tools/caffe train -solver /Users/Young/Documents/Programming/MTCNN/MTCNN_train/ONet_solver.prototxt -weights /Users/Young/Documents/Programming/MTCNN/model/det3.caffemodel