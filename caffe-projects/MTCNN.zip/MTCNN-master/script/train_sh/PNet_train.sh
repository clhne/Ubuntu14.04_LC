#!/usr/bin/env sh
set -e

/Users/Young/caffe/.build_release/tools/caffe train -solver /Users/Young/Documents/Programming/MTCNN/MTCNN_train/PNet_solver.prototxt -weights /Users/Young/Documents/Programming/MTCNN/model/det1.caffemodel